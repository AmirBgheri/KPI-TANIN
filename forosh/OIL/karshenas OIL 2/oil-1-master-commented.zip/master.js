// ========================================================
// OIL SALES EXPERT DASHBOARD
// کارتابل کارشناس فروش روغن
// ========================================================
//
// منطق کلی این فایل:
//
// 1) اطلاعات فروش از MockAPI دریافت می‌شود.
// 2) هر رکورد دیتابیس متعلق به یک کارشناس + یک تیم + یک سال + یک ماه است.
// 3) فعالیت‌های همان ماه داخل فیلد ACTIVITIES همان رکورد ذخیره می‌شوند.
// 4) با تغییر ماه، رکورد همان ماه پیدا شده و KPIها، نمودار کالا و جدول فعالیت‌ها تغییر می‌کنند.
// 5) نمودار روند فروش ماهانه، همه 12 ماه سال را همزمان نمایش می‌دهد.
// 6) ثبت / ویرایش / حذف فعالیت باعث بروزرسانی ACTIVITIES همان ماه می‌شود.
//
// مثال:
// NAME = امیر باقری
// TEAM = OIL
// YEAR = 1405
// MONTH = فروردین
// ACTIVITIES = [ ... ]
//
// یعنی برای هر ماه فقط یک رکورد اصلی داریم و فعالیت‌ها داخل آن هستند.
// ========================================================



// ========================================================
// 1. تنظیمات اصلی پروژه
// ========================================================

// آدرس Resource فروش در MockAPI
// تمام اطلاعات تیم فروش روغن و کامپیوتر می‌تواند در همین Resource باشد.
const API_URL =
  "https://6a968499fa33b37f821b50b6.mockapi.io/FOROSH";


// نام کارشناس این کارتابل.
// برای ساخت کارتابل کارشناس دوم فقط همین مقدار را تغییر می‌دهیم.
const EXPERT_NAME =
  "امیر باقری";


// نام تیم.
// برای کارشناسان روغن مقدار OIL و برای کامپیوتر می‌تواند COMPUTER باشد.
const TEAM =
  "OIL";


// سالی که داشبورد در حال نمایش آن است.
const CURRENT_YEAR =
  1405;


// مسیر برگشت به صفحه اصلی فروش
const SALES_HOME_PAGE =
  "../../index.html";



// ========================================================
// 2. لیست ماه‌های شمسی
// ========================================================
//
// ترتیب این آرایه مهم است.
// هم برای جابه‌جایی ماه‌ها استفاده می‌شود
// و هم محور افقی نمودار سالانه از همین آرایه ساخته می‌شود.
//
const MONTHS = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند"
];



// ========================================================
// 3. متغیرهای اصلی برنامه
// ========================================================

// شماره ماهی که در حال حاضر در صفحه انتخاب شده است.
// 0 = فروردین
// 1 = اردیبهشت
// ...
// 11 = اسفند
let selectedMonthIndex =
  0;


// بعد از GET گرفتن از MockAPI، فقط رکوردهای همین کارشناس
// در این آرایه نگهداری می‌شوند.
let expertRecords =
  [];


// این دو متغیر Instance نمودارهای Chart.js را نگهداری می‌کنند.
// قبل از رسم مجدد نمودار، Instance قبلی Destroy می‌شود
// تا نمودارها روی هم نیفتند.
let monthlyTrendChart =
  null;

let productSalesChart =
  null;



// ========================================================
// 4. تابع کمکی برای گرفتن Element با ID
// ========================================================
//
// به جای اینکه هر بار بنویسیم:
// document.getElementById("...")
//
// فقط می‌نویسیم:
// $("...")
//
const $ =
  (id) =>
    document.getElementById(id);



// ========================================================
// 5. گرفتن Elementهای HTML
// ========================================================

// اطلاعات هدر
const headerDate =
  $("headerDate");

const headerExpertName =
  $("headerExpertName");

const welcomeText =
  $("welcomeText");


// انتخاب ماه
const selectedMonthLabel =
  $("selectedMonthLabel");

const prevMonthBtn =
  $("prevMonthBtn");

const nextMonthBtn =
  $("nextMonthBtn");


// KPI و تارگت
const targetPercentText =
  $("targetPercentText");

const targetProgress =
  $("targetProgress");

const salesAmountValue =
  $("salesAmountValue");

const orderCountValue =
  $("orderCountValue");

const productCountValue =
  $("productCountValue");

const profitMarginValue =
  $("profitMarginValue");

const targetValue =
  $("targetValue");


// عنوان ماه در نمودار کالا و جدول فعالیت‌ها
const productChartMonth =
  $("productChartMonth");

const activitiesMonthLabel =
  $("activitiesMonthLabel");


// فرم ثبت فعالیت
const activityForm =
  $("activityForm");

const editingActivityId =
  $("editingActivityId");

const activityDate =
  $("activityDate");

const activityType =
  $("activityType");

const customerInput =
  $("customerInput");

const productInput =
  $("productInput");

const salesAmountInput =
  $("salesAmountInput");

const orderCountInput =
  $("orderCountInput");

const profitMarginInput =
  $("profitMarginInput");

const descriptionInput =
  $("descriptionInput");

const saveActivityBtn =
  $("saveActivityBtn");

const clearFormBtn =
  $("clearFormBtn");

const formMessage =
  $("formMessage");


// جدول فعالیت‌ها
const showActivitiesBtn =
  $("showActivitiesBtn");

const activitiesWrapper =
  $("activitiesWrapper");

const activitiesTableBody =
  $("activitiesTableBody");

const emptyActivities =
  $("emptyActivities");


// Loading و خروج
const loadingOverlay =
  $("loadingOverlay");

const logoutBtn =
  $("logoutBtn");



// ========================================================
// 6. شروع برنامه
// ========================================================
//
// وقتی HTML کامل Load شد، تابع initDashboard اجرا می‌شود.
//
document.addEventListener(
  "DOMContentLoaded",
  initDashboard
);


async function initDashboard() {

  // نمایش نام کارشناس در هدر
  headerExpertName.textContent =
    EXPERT_NAME;


  // متن خوش‌آمدگویی
  welcomeText.textContent =
    `سلام ${EXPERT_NAME}`;


  // نمایش تاریخ امروز
  setHeaderDate();


  // داشبورد در شروع روی ماه شمسی فعلی قرار می‌گیرد.
  selectedMonthIndex =
    getCurrentPersianMonthIndex();


  // تاریخ امروز به صورت پیش‌فرض داخل فرم ثبت فعالیت قرار می‌گیرد.
  setDefaultActivityDate();


  // Event Listenerهای صفحه فعال می‌شوند.
  bindEvents();


  // اطلاعات از API دریافت می‌شود.
  await refreshData();
}



// ========================================================
// 7. Event Listenerهای اصلی صفحه
// ========================================================

function bindEvents() {

  // رفتن به ماه قبل
  prevMonthBtn.addEventListener(
    "click",
    () => changeMonth(-1)
  );


  // رفتن به ماه بعد
  nextMonthBtn.addEventListener(
    "click",
    () => changeMonth(1)
  );


  // ثبت فرم
  activityForm.addEventListener(
    "submit",
    handleActivitySubmit
  );


  // پاک کردن فرم
  clearFormBtn.addEventListener(
    "click",
    clearActivityForm
  );


  // نمایش / مخفی کردن فعالیت‌های ماه
  showActivitiesBtn.addEventListener(
    "click",
    toggleActivities
  );


  // خروج از کارتابل
  logoutBtn.addEventListener(
    "click",
    () =>
      window.location.href =
        SALES_HOME_PAGE
  );
}



// ========================================================
// 8. تغییر ماه
// ========================================================
//
// step = -1  => ماه قبلی
// step = 1   => ماه بعدی
//
// استفاده از % 12 باعث می‌شود:
//
// اگر از فروردین یک ماه عقب برویم => اسفند
// اگر از اسفند یک ماه جلو برویم => فروردین
//
function changeMonth(step) {

  selectedMonthIndex =
    (
      selectedMonthIndex +
      step +
      12
    ) % 12;


  // بعد از تغییر ماه، اطلاعات همان ماه روی صفحه نمایش داده می‌شود.
  loadSelectedMonth();
}



// ========================================================
// 9. نمایش تاریخ شمسی امروز در هدر
// ========================================================

function setHeaderDate() {

  headerDate.textContent =
    new Date()
      .toLocaleDateString(
        "fa-IR-u-ca-persian",
        {
          weekday:
            "long",

          year:
            "numeric",

          month:
            "long",

          day:
            "numeric"
        }
      );
}



// ========================================================
// 10. تشخیص ماه شمسی فعلی
// ========================================================
//
// Intl تاریخ امروز را به شمسی تبدیل می‌کند.
// سپس نام ماه را با آرایه MONTHS مقایسه می‌کنیم.
//
function getCurrentPersianMonthIndex() {

  try {

    const monthText =
      new Intl.DateTimeFormat(
        "fa-IR-u-ca-persian",
        {
          month:
            "long"
        }
      )
      .format(
        new Date()
      );


    const index =
      MONTHS.findIndex(
        month =>
          monthText.includes(month)
      );


    // اگر ماه پیدا نشد، فروردین انتخاب می‌شود.
    return index >= 0
      ? index
      : 0;

  }

  catch {

    return 0;

  }
}



// ========================================================
// 11. قرار دادن تاریخ امروز داخل فرم
// ========================================================
//
// nu-latn باعث می‌شود اعداد تاریخ انگلیسی باشند.
// مثال:
// 1405/01/16
//
function setDefaultActivityDate() {

  try {

    activityDate.value =
      new Intl.DateTimeFormat(
        "fa-IR-u-ca-persian-nu-latn",
        {
          year:
            "numeric",

          month:
            "2-digit",

          day:
            "2-digit"
        }
      )
      .format(
        new Date()
      )
      .replace(
        /‏/g,
        ""
      );

  }

  catch {

    // مقدار جایگزین در صورت عدم پشتیبانی مرورگر
    activityDate.value =
      `${CURRENT_YEAR}/01/01`;

  }
}



// ========================================================
// 12. توابع ارتباط با MockAPI
// ========================================================


// --------------------------------------------------------
// GET
// دریافت تمام رکوردهای Resource فروش
// --------------------------------------------------------
async function fetchAllData() {

  const response =
    await fetch(
      API_URL
    );


  if (
    !response.ok
  ) {

    throw new Error(
      "GET failed"
    );

  }


  return response.json();
}



// --------------------------------------------------------
// POST
// ساخت رکورد جدید
//
// این تابع فقط زمانی استفاده می‌شود که برای ماه انتخاب‌شده
// هنوز رکوردی در MockAPI وجود نداشته باشد.
// --------------------------------------------------------
async function createRecord(body) {

  const response =
    await fetch(
      API_URL,
      {
        method:
          "POST",

        headers: {
          "Content-Type":
            "application/json"
        },

        body:
          JSON.stringify(body)
      }
    );


  if (
    !response.ok
  ) {

    throw new Error(
      "POST failed"
    );

  }


  return response.json();
}



// --------------------------------------------------------
// PUT
// بروزرسانی رکورد موجود یک ماه
//
// نکته مهم:
// برای هر فعالیت POST جدا نمی‌زنیم.
// ACTIVITIES همان رکورد ماه را بروزرسانی می‌کنیم.
// --------------------------------------------------------
async function updateRecord(
  id,
  body
) {

  const response =
    await fetch(
      `${API_URL}/${id}`,
      {
        method:
          "PUT",

        headers: {
          "Content-Type":
            "application/json"
        },

        body:
          JSON.stringify(body)
      }
    );


  if (
    !response.ok
  ) {

    throw new Error(
      "PUT failed"
    );

  }


  return response.json();
}



// ========================================================
// 13. دریافت اطلاعات و فیلتر کردن رکوردهای این کارشناس
// ========================================================

async function refreshData() {

  showLoading(true);


  try {

    // همه رکوردهای Resource فروش
    const data =
      await fetchAllData();


    // فقط رکوردهای:
    // 1) همین کارشناس
    // 2) همین تیم
    // 3) همین سال
    //
    // در expertRecords ذخیره می‌شوند.
    expertRecords =
      data.filter(
        record =>

          normalizeText(
            record.NAME
          ) ===
          normalizeText(
            EXPERT_NAME
          )

          &&

          normalizeText(
            record.TEAM
          ) ===
          normalizeText(
            TEAM
          )

          &&

          Number(
            record.YEAR
          ) ===
          Number(
            CURRENT_YEAR
          )
      );


    // اطلاعات ماه انتخاب‌شده روی صفحه قرار می‌گیرد.
    loadSelectedMonth();


    // نمودار روند کل سال ساخته می‌شود.
    renderMonthlyTrendChart();

  }

  catch (error) {

    console.error(error);


    showMessage(
      "خطا در دریافت اطلاعات از دیتابیس.",
      "error"
    );

  }

  finally {

    showLoading(false);

  }
}



// ========================================================
// 14. گرفتن نام ماه انتخاب‌شده
// ========================================================

function getSelectedMonthName() {

  return MONTHS[
    selectedMonthIndex
  ];
}



// ========================================================
// 15. پیدا کردن رکورد ماه انتخاب‌شده
// ========================================================
//
// مثال:
//
// selectedMonth = فروردین
//
// در expertRecords دنبال رکوردی می‌گردیم که:
// MONTH === "فروردین"
//
// اگر وجود نداشت null برمی‌گردد.
//
function getSelectedMonthRecord() {

  const month =
    getSelectedMonthName();


  return expertRecords.find(
    record =>

      normalizeText(
        record.MONTH
      ) ===
      normalizeText(
        month
      )
  ) || null;
}



// ========================================================
// 16. نمایش اطلاعات ماه انتخاب‌شده
// ========================================================
//
// این تابع مرکز اصلی تغییر ماه است.
//
// با هر تغییر ماه:
//
// 1) Label ماه تغییر می‌کند.
// 2) ACTIVITIES همان ماه گرفته می‌شود.
// 3) KPIها محاسبه می‌شوند.
// 4) نمودار کالا تغییر می‌کند.
// 5) اگر جدول فعالیت‌ها باز باشد، جدول هم بروزرسانی می‌شود.
// ========================================================

function loadSelectedMonth() {

  const month =
    getSelectedMonthName();


  const record =
    getSelectedMonthRecord();


  const label =
    `${month} ${toPersianDigits(
      CURRENT_YEAR
    )}`;


  // نمایش ماه در سه قسمت صفحه
  selectedMonthLabel.textContent =
    label;

  productChartMonth.textContent =
    label;

  activitiesMonthLabel.textContent =
    label;


  // گرفتن فعالیت‌های همان ماه
  const activities =
    getActivities(
      record
    );


  // محاسبه KPIهای ماه
  const summary =
    calculateSummary(
      activities,
      record
    );


  // نمایش KPIها
  renderKpis(
    summary
  );


  // نمودار فروش براساس کالا فقط مربوط به ماه انتخاب‌شده است.
  renderProductChart(
    activities
  );


  // اگر جدول فعالیت‌ها باز باشد،
  // با تغییر ماه محتویات جدول نیز تغییر می‌کند.
  if (
    !activitiesWrapper
      .classList
      .contains(
        "hidden"
      )
  ) {

    renderActivities(
      activities
    );

  }


  // فرم برای ماه جدید پاک می‌شود.
  clearActivityForm();
}



// ========================================================
// 17. استخراج ACTIVITIES از رکورد
// ========================================================
//
// MockAPI ممکن است ACTIVITIES را:
//
// 1) Array واقعی برگرداند
// یا
// 2) String JSON برگرداند
//
// این تابع هر دو حالت را پشتیبانی می‌کند.
//
// اگر هیچ Activity وجود نداشته باشد => []
//
function getActivities(record) {

  if (
    !record ||
    record.ACTIVITIES == null
  ) {

    return [];

  }


  // حالت استاندارد: Array
  if (
    Array.isArray(
      record.ACTIVITIES
    )
  ) {

    return record.ACTIVITIES;

  }


  // حالت دوم: JSON String
  if (
    typeof record.ACTIVITIES ===
    "string"
  ) {

    try {

      const parsed =
        JSON.parse(
          record.ACTIVITIES
        );


      return Array.isArray(
        parsed
      )
        ? parsed
        : [];

    }

    catch {

      return [];

    }

  }


  return [];
}



// ========================================================
// 18. گرفتن تارگت ماه
// ========================================================
//
// TARGET در سطح رکورد ماه ذخیره می‌شود.
// یعنی هر ماه می‌تواند Target مخصوص خودش را داشته باشد.
//
function getTarget(record) {

  return record
    ? Number(
        record.TARGET ||
        0
      )
    : 0;
}



// ========================================================
// 19. محاسبه KPIهای ماه
// ========================================================
//
// ورودی:
// activities = فعالیت‌های ماه
// record     = رکورد ماه
//
// خروجی:
//
// salesAmount   = مجموع مبلغ فروش
// orderCount    = مجموع تعداد سفارش
// productCount  = تعداد کالاهای یکتا
// profitMargin  = میانگین وزنی حاشیه سود
// target        = تارگت ماه
// targetPercent = درصد تحقق تارگت
// ========================================================

function calculateSummary(
  activities,
  record
) {

  // ------------------------------------------------------
  // مجموع مبلغ فروش ماه
  // ------------------------------------------------------
  const salesAmount =
    activities.reduce(
      (
        sum,
        activity
      ) =>

        sum +
        Number(
          activity.amount ||
          0
        ),

      0
    );


  // ------------------------------------------------------
  // مجموع تعداد سفارش‌های ماه
  // ------------------------------------------------------
  const orderCount =
    activities.reduce(
      (
        sum,
        activity
      ) =>

        sum +
        Number(
          activity.orderCount ||
          0
        ),

      0
    );


  // ------------------------------------------------------
  // تعداد کالاهای متفاوت
  //
  // Set مقدار تکراری را فقط یک بار نگه می‌دارد.
  //
  // مثال:
  // 20W-50
  // 20W-50
  // Gear Oil
  //
  // productCount = 2
  // ------------------------------------------------------
  const products =
    new Set(
      activities
        .map(
          activity =>
            normalizeText(
              activity.product
            )
        )
        .filter(
          Boolean
        )
    );


  // ------------------------------------------------------
  // محاسبه حاشیه سود میانگین وزنی
  //
  // دلیل استفاده از Weighted Average:
  // فروش بزرگ‌تر باید تاثیر بیشتری روی سود کل داشته باشد.
  //
  // مثال:
  // فروش 100 میلیون با سود 10%
  // فروش 1 میلیارد با سود 20%
  //
  // میانگین ساده مناسب نیست.
  // ------------------------------------------------------
  const weightedProfit =
    activities.reduce(
      (
        sum,
        activity
      ) => {

        return (
          sum +
          Number(
            activity.amount ||
            0
          )
          *
          Number(
            activity.profitMargin ||
            0
          )
        );

      },
      0
    );


  const profitMargin =
    salesAmount > 0

      ? weightedProfit /
        salesAmount

      : 0;


  // تارگت همان ماه
  const target =
    getTarget(
      record
    );


  // درصد تحقق تارگت
  //
  // مثال:
  // فروش = 8.5 میلیارد
  // تارگت = 10 میلیارد
  //
  // درصد تحقق = 85%
  const targetPercent =
    target > 0

      ? (
          salesAmount /
          target
        ) *
        100

      : 0;


  return {

    salesAmount,

    orderCount,

    productCount:
      products.size,

    profitMargin,

    target,

    targetPercent

  };
}



// ========================================================
// 20. نمایش KPIها روی صفحه
// ========================================================

function renderKpis(summary) {

  // مبلغ فروش
  salesAmountValue.textContent =
    formatNumber(
      summary.salesAmount
    );


  // تعداد سفارش
  orderCountValue.textContent =
    formatNumber(
      summary.orderCount
    );


  // تعداد نوع کالا
  productCountValue.textContent =
    formatNumber(
      summary.productCount
    );


  // حاشیه سود
  profitMarginValue.textContent =
    `${formatDecimal(
      summary.profitMargin
    )}٪`;


  // تارگت
  targetValue.textContent =
    formatNumber(
      summary.target
    );


  // درصد تحقق
  targetPercentText.textContent =
    `${formatDecimal(
      summary.targetPercent
    )}٪`;


  // Progress Bar
  //
  // حتی اگر تحقق بیشتر از 100% شود،
  // عرض نوار بیشتر از 100% نمی‌شود.
  targetProgress.style.width =
    `${Math.min(
      Math.max(
        summary.targetPercent,
        0
      ),
      100
    )}%`;
}



// ========================================================
// 21. ثبت یا ویرایش فعالیت
// ========================================================
//
// این تابع هنگام Submit فرم اجرا می‌شود.
//
// روند:
//
// 1) اطلاعات فرم خوانده می‌شود.
// 2) اعتبارسنجی انجام می‌شود.
// 3) رکورد ماه پیدا می‌شود.
// 4) اگر در حالت Edit باشیم Activity جایگزین می‌شود.
// 5) اگر Activity جدید باشد به Array اضافه می‌شود.
// 6) KPIهای ماه دوباره محاسبه می‌شوند.
// 7) اگر رکورد ماه وجود دارد => PUT
// 8) اگر رکورد ماه وجود ندارد => POST
// ========================================================

async function handleActivitySubmit(event) {

  // جلوگیری از Reload شدن صفحه
  event.preventDefault();


  // خواندن اطلاعات فرم
  const activity =
    readActivityForm();


  // اگر اطلاعات معتبر نیست، ادامه نده.
  if (
    !validateActivity(
      activity
    )
  ) {

    return;

  }


  showLoading(true);


  try {

    // رکورد ماه انتخاب‌شده
    const record =
      getSelectedMonthRecord();


    // کپی Activityها
    //
    // با Spread یک Array جدید می‌سازیم
    // تا مستقیم Array اصلی را تغییر ندهیم.
    let activities =
      [
        ...getActivities(
          record
        )
      ];


    // اگر این Input مقدار داشته باشد یعنی در حالت ویرایش هستیم.
    const editId =
      editingActivityId.value;


    if (
      editId
    ) {

      // ----------------------------------------------------
      // حالت ویرایش
      //
      // Activity مورد نظر را با Activity جدید جایگزین می‌کنیم.
      // id قبلی حفظ می‌شود.
      // ----------------------------------------------------
      activities =
        activities.map(
          item =>

            String(
              item.id
            ) ===
            String(
              editId
            )

              ? {
                  ...activity,
                  id:
                    item.id
                }

              : item
        );

    }

    else {

      // ----------------------------------------------------
      // حالت ثبت Activity جدید
      // ----------------------------------------------------

      // برای هر Activity یک ID داخلی می‌سازیم.
      // این ID با ID رکورد MockAPI فرق دارد.
      activity.id =
        createActivityId();


      // Activity جدید به Array همان ماه اضافه می‌شود.
      activities.push(
        activity
      );

    }


    // بعد از تغییر Activityها،
    // KPIهای ماه دوباره محاسبه می‌شوند.
    const summary =
      calculateSummary(
        activities,
        record
      );


    // ساخت Body نهایی برای MockAPI
    const body =
      buildRecordBody(
        activities,
        summary,
        record
      );


    if (
      record
    ) {

      // رکورد ماه از قبل وجود دارد.
      // فقط همان رکورد را PUT می‌کنیم.
      await updateRecord(
        record.id,
        body
      );

    }

    else {

      // برای این ماه هنوز رکوردی وجود ندارد.
      // اولین Activity باعث ساخت رکورد ماه می‌شود.
      await createRecord(
        body
      );

    }


    // اطلاعات دوباره از دیتابیس خوانده می‌شوند
    // تا صفحه دقیقاً با اطلاعات ذخیره‌شده Sync شود.
    await refreshData();


    // بعد از ثبت، جدول Activityها باز می‌شود.
    activitiesWrapper
      .classList
      .remove(
        "hidden"
      );


    showActivitiesBtn.textContent =
      "بستن فعالیت‌ها";


    renderActivities(
      getActivities(
        getSelectedMonthRecord()
      )
    );


    showMessage(
      editId
        ? "فعالیت ویرایش شد."
        : "فعالیت ثبت شد.",
      "success"
    );

  }

  catch (error) {

    console.error(error);


    showMessage(
      "ثبت اطلاعات انجام نشد.",
      "error"
    );

  }

  finally {

    showLoading(false);

  }
}



// ========================================================
// 22. خواندن اطلاعات فرم
// ========================================================

function readActivityForm() {

  return {

    // تاریخ Activity
    date:
      activityDate.value.trim(),

    // نوع Activity
    type:
      activityType.value,

    // مشتری
    customer:
      customerInput.value.trim(),

    // کالا
    product:
      productInput.value.trim(),

    // مبلغ فروش
    amount:
      Number(
        salesAmountInput.value ||
        0
      ),

    // تعداد سفارش
    orderCount:
      Number(
        orderCountInput.value ||
        0
      ),

    // حاشیه سود
    profitMargin:
      Number(
        profitMarginInput.value ||
        0
      ),

    // توضیحات
    description:
      descriptionInput.value.trim()

  };
}



// ========================================================
// 23. اعتبارسنجی فرم
// ========================================================

function validateActivity(
  activity
) {

  if (
    !activity.date
  ) {

    return showValidation(
      "تاریخ فعالیت را وارد کنید."
    );

  }


  if (
    !activity.customer
  ) {

    return showValidation(
      "نام مشتری را وارد کنید."
    );

  }


  if (
    !activity.product
  ) {

    return showValidation(
      "نام کالا را وارد کنید."
    );

  }


  if (
    activity.amount < 0 ||
    activity.orderCount < 0 ||
    activity.profitMargin < 0
  ) {

    return showValidation(
      "مقادیر عددی نمی‌توانند منفی باشند."
    );

  }


  return true;
}



// تابع کمکی برای نمایش خطای Validation
function showValidation(message) {

  showMessage(
    message,
    "error"
  );

  return false;
}



// ========================================================
// 24. ساخت Body رکورد MockAPI
// ========================================================
//
// این Body همان ساختاری است که در دیتابیس ذخیره می‌شود.
//
// نکته مهم:
//
// SALES-AMOUNT
// ORDER-COUNT
// PROFIT-MARGIN
//
// از روی ACTIVITIES محاسبه می‌شوند.
// یعنی کارشناس مستقیماً KPI ماه را وارد نمی‌کند.
//
// ACTIVITIES منبع اصلی داده است.
// ========================================================

function buildRecordBody(
  activities,
  summary,
  existingRecord
) {

  return {

    // نام کارشناس
    NAME:
      EXPERT_NAME,

    // تیم فروش
    TEAM,

    // سال
    YEAR:
      CURRENT_YEAR,

    // ماه فعلی
    MONTH:
      getSelectedMonthName(),

    // تارگت از رکورد قبلی حفظ می‌شود.
    // فعلاً کارشناس Target را تغییر نمی‌دهد.
    TARGET:
      getTarget(
        existingRecord
      ),

    // مجموع فروش محاسبه‌شده
    "SALES-AMOUNT":
      summary.salesAmount,

    // مجموع سفارش‌ها
    "ORDER-COUNT":
      summary.orderCount,

    // حاشیه سود میانگین وزنی
    "PROFIT-MARGIN":
      Number(
        summary.profitMargin.toFixed(
          2
        )
      ),

    // تمام Activityهای همین ماه
    ACTIVITIES:
      activities

  };
}



// ========================================================
// 25. پاک کردن فرم
// ========================================================

function clearActivityForm() {

  // خارج شدن از حالت ویرایش
  editingActivityId.value =
    "";


  activityType.value =
    "فروش";


  customerInput.value =
    "";


  productInput.value =
    "";


  salesAmountInput.value =
    "";


  orderCountInput.value =
    "";


  profitMarginInput.value =
    "";


  descriptionInput.value =
    "";


  // متن دکمه دوباره به حالت ثبت برمی‌گردد.
  saveActivityBtn.textContent =
    "+ ثبت اطلاعات";


  // تاریخ امروز دوباره داخل فرم قرار می‌گیرد.
  setDefaultActivityDate();
}



// ========================================================
// 26. باز / بسته کردن جدول Activityها
// ========================================================

function toggleActivities() {

  const isHidden =
    activitiesWrapper
      .classList
      .contains(
        "hidden"
      );


  if (
    isHidden
  ) {

    // نمایش جدول
    activitiesWrapper
      .classList
      .remove(
        "hidden"
      );


    showActivitiesBtn.textContent =
      "بستن فعالیت‌ها";


    // فقط Activityهای همان ماه نمایش داده می‌شوند.
    renderActivities(
      getActivities(
        getSelectedMonthRecord()
      )
    );

  }

  else {

    // مخفی کردن جدول
    activitiesWrapper
      .classList
      .add(
        "hidden"
      );


    showActivitiesBtn.textContent =
      "مشاهده فعالیت‌ها";

  }
}



// ========================================================
// 27. ساخت جدول Activityها با createElement
// ========================================================
//
// طبق ساختاری که برای پروژه خواستیم:
//
// جدول Activityها Static نیست.
//
// برای هر Activity:
//
// document.createElement("tr")
//
// ساخته می‌شود.
//
// Activityهای جدیدتر با reverse در بالای جدول دیده می‌شوند.
// ========================================================

function renderActivities(
  activities
) {

  // پاک کردن جدول قبلی
  activitiesTableBody.innerHTML =
    "";


  // اگر Activity نداریم
  if (
    !activities.length
  ) {

    emptyActivities
      .classList
      .remove(
        "hidden"
      );

    return;

  }


  emptyActivities
    .classList
    .add(
      "hidden"
    );


  // slice() برای ساخت Copy از Array است.
  // بعد reverse() می‌کنیم تا جدیدترین Activity اول نمایش داده شود.
  activities
    .slice()
    .reverse()
    .forEach(
      activity => {


        // ساخت Row
        const row =
          document.createElement(
            "tr"
          );


        row.className =
          "hover:bg-emerald-50/40 transition";


        // سلول‌های Activity
        appendCell(
          row,
          activity.date ||
          "-"
        );


        appendCell(
          row,
          activity.type ||
          "-"
        );


        appendCell(
          row,
          activity.customer ||
          "-"
        );


        appendCell(
          row,
          activity.product ||
          "-"
        );


        appendCell(
          row,
          formatNumber(
            activity.orderCount ||
            0
          )
        );


        appendCell(
          row,
          formatNumber(
            activity.amount ||
            0
          )
        );


        appendCell(
          row,
          `${formatDecimal(
            activity.profitMargin ||
            0
          )}٪`
        );


        appendCell(
          row,
          activity.description ||
          "-"
        );


        // ----------------------------------------------------
        // ستون عملیات
        // ----------------------------------------------------
        const actionsCell =
          document.createElement(
            "td"
          );


        actionsCell.className =
          "px-4 py-3";


        const actions =
          document.createElement(
            "div"
          );


        actions.className =
          "flex items-center gap-2";


        // ----------------------------------------------------
        // دکمه ویرایش
        // ----------------------------------------------------
        const editBtn =
          document.createElement(
            "button"
          );


        editBtn.type =
          "button";


        editBtn.className =
          "px-3 py-1.5 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 transition";


        editBtn.textContent =
          "ویرایش";


        editBtn.addEventListener(
          "click",
          () =>
            editActivity(
              activity
            )
        );


        // ----------------------------------------------------
        // دکمه حذف
        // ----------------------------------------------------
        const deleteBtn =
          document.createElement(
            "button"
          );


        deleteBtn.type =
          "button";


        deleteBtn.className =
          "px-3 py-1.5 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition";


        deleteBtn.textContent =
          "حذف";


        deleteBtn.addEventListener(
          "click",
          () =>
            deleteActivity(
              activity.id
            )
        );


        actions.append(
          editBtn,
          deleteBtn
        );


        actionsCell.appendChild(
          actions
        );


        row.appendChild(
          actionsCell
        );


        activitiesTableBody
          .appendChild(
            row
          );

      }
    );
}



// ========================================================
// 28. تابع کمکی ساخت Cell جدول
// ========================================================
//
// به جای اینکه برای هر td کد جدا تکرار کنیم،
// این تابع یک Cell می‌سازد و به Row اضافه می‌کند.
//
function appendCell(
  row,
  value
) {

  const cell =
    document.createElement(
      "td"
    );


  cell.className =
    "px-4 py-3 whitespace-nowrap";


  // استفاده از textContent امن‌تر از innerHTML است.
  cell.textContent =
    value;


  row.appendChild(
    cell
  );
}



// ========================================================
// 29. ویرایش Activity
// ========================================================
//
// با زدن دکمه ویرایش:
//
// 1) ID Activity داخل hidden input قرار می‌گیرد.
// 2) اطلاعات Activity داخل فرم می‌آید.
// 3) متن دکمه به "ذخیره ویرایش" تغییر می‌کند.
// 4) صفحه به فرم Scroll می‌شود.
// ========================================================

function editActivity(activity) {

  editingActivityId.value =
    activity.id;


  activityDate.value =
    activity.date ||
    "";


  activityType.value =
    activity.type ||
    "فروش";


  customerInput.value =
    activity.customer ||
    "";


  productInput.value =
    activity.product ||
    "";


  salesAmountInput.value =
    activity.amount ||
    "";


  orderCountInput.value =
    activity.orderCount ||
    "";


  profitMarginInput.value =
    activity.profitMargin ||
    "";


  descriptionInput.value =
    activity.description ||
    "";


  saveActivityBtn.textContent =
    "ذخیره ویرایش";


  activityForm.scrollIntoView(
    {
      behavior:
        "smooth",

      block:
        "start"
    }
  );
}



// ========================================================
// 30. حذف Activity
// ========================================================
//
// حذف Activity به معنی حذف کل رکورد ماه نیست.
//
// فقط آن Activity از Array حذف می‌شود
// و سپس رکورد ماه با PUT بروزرسانی می‌شود.
// ========================================================

async function deleteActivity(
  activityId
) {

  // گرفتن تایید از کاربر
  if (
    !confirm(
      "این فعالیت حذف شود؟"
    )
  ) {

    return;

  }


  // رکورد ماه فعلی
  const record =
    getSelectedMonthRecord();


  if (
    !record
  ) {

    return;

  }


  showLoading(true);


  try {

    // همه Activityها به جز Activity انتخاب‌شده
    const activities =
      getActivities(
        record
      )
      .filter(
        activity =>

          String(
            activity.id
          ) !==
          String(
            activityId
          )
      );


    // KPIها بعد از حذف دوباره محاسبه می‌شوند.
    const summary =
      calculateSummary(
        activities,
        record
      );


    const body =
      buildRecordBody(
        activities,
        summary,
        record
      );


    // همان رکورد ماه بروزرسانی می‌شود.
    await updateRecord(
      record.id,
      body
    );


    // دریافت نسخه جدید اطلاعات
    await refreshData();


    // جدول باز می‌ماند.
    activitiesWrapper
      .classList
      .remove(
        "hidden"
      );


    showActivitiesBtn.textContent =
      "بستن فعالیت‌ها";


    renderActivities(
      getActivities(
        getSelectedMonthRecord()
      )
    );


    showMessage(
      "فعالیت حذف شد.",
      "success"
    );

  }

  catch (error) {

    console.error(error);


    showMessage(
      "حذف فعالیت انجام نشد.",
      "error"
    );

  }

  finally {

    showLoading(false);

  }
}



// ========================================================
// 31. نمودار روند فروش ماهانه
// ========================================================
//
// این نمودار برخلاف نمودار کالا فقط مربوط به ماه انتخاب‌شده نیست.
//
// همه 12 ماه سال را نشان می‌دهد.
//
// Dataset اول:
// Bar = مبلغ فروش
//
// Dataset دوم:
// Line = تعداد سفارش
// ========================================================

function renderMonthlyTrendChart() {

  // ------------------------------------------------------
  // ساخت آرایه مبلغ فروش 12 ماه
  // ------------------------------------------------------
  const salesData =
    MONTHS.map(
      month => {

        // رکورد همین ماه
        const record =
          expertRecords.find(
            item =>

              normalizeText(
                item.MONTH
              ) ===
              normalizeText(
                month
              )
          );


        // مبلغ فروش از Activityهای همان ماه محاسبه می‌شود.
        return calculateSummary(
          getActivities(
            record
          ),
          record
        )
        .salesAmount;

      }
    );


  // ------------------------------------------------------
  // ساخت آرایه تعداد سفارش 12 ماه
  // ------------------------------------------------------
  const orderData =
    MONTHS.map(
      month => {

        const record =
          expertRecords.find(
            item =>

              normalizeText(
                item.MONTH
              ) ===
              normalizeText(
                month
              )
          );


        return calculateSummary(
          getActivities(
            record
          ),
          record
        )
        .orderCount;

      }
    );


  const context =
    $("monthlyTrendChart")
      .getContext(
        "2d"
      );


  // جلوگیری از ساخته شدن چند نمودار روی یک Canvas
  if (
    monthlyTrendChart
  ) {

    monthlyTrendChart.destroy();

  }


  monthlyTrendChart =
    new Chart(
      context,
      {
        data: {

          labels:
            MONTHS,

          datasets: [

            {
              // مبلغ فروش به شکل Bar
              type:
                "bar",

              label:
                "مبلغ فروش (میلیون ریال)",

              // مبلغ برای خوانایی به میلیون ریال تبدیل می‌شود.
              data:
                salesData.map(
                  value =>
                    value /
                    1000000
                ),

              backgroundColor:
                "rgba(5,150,105,.75)",

              borderRadius:
                7,

              yAxisID:
                "y"
            },

            {
              // تعداد سفارش به شکل Line
              type:
                "line",

              label:
                "تعداد سفارش",

              data:
                orderData,

              borderColor:
                "#F59E0B",

              backgroundColor:
                "#F59E0B",

              tension:
                0.3,

              pointRadius:
                4,

              yAxisID:
                "y1"
            }

          ]

        },

        options: {

          responsive:
            true,

          maintainAspectRatio:
            false,

          interaction: {
            mode:
              "index",

            intersect:
              false
          },

          plugins: {

            legend: {
              position:
                "top"
            }

          },

          scales: {

            // محور مبلغ فروش
            y: {
              beginAtZero:
                true,

              position:
                "left",

              grid: {
                color:
                  "#E2E8F0"
              }
            },

            // محور تعداد سفارش
            y1: {
              beginAtZero:
                true,

              position:
                "right",

              grid: {
                drawOnChartArea:
                  false
              }
            }

          }

        }
      }
    );
}



// ========================================================
// 32. نمودار فروش بر اساس کالا
// ========================================================
//
// این نمودار فقط مربوط به ماه انتخاب‌شده است.
//
// ابتدا مبلغ فروش تمام Activityهای یک کالا با هم جمع می‌شود.
//
// مثال:
//
// 20W-50 = 500 میلیون
// 20W-50 = 300 میلیون
//
// نمودار:
// 20W-50 = 800 میلیون
// ========================================================

function renderProductChart(
  activities
) {

  // Object برای جمع فروش هر Product
  const productMap =
    {};


  activities.forEach(
    activity => {

      const product =
        (
          activity.product ||
          "نامشخص"
        )
        .trim();


      if (
        !productMap[
          product
        ]
      ) {

        productMap[
          product
        ] =
          0;

      }


      productMap[
        product
      ] +=
        Number(
          activity.amount ||
          0
        );

    }
  );


  // نام کالاها
  const labels =
    Object.keys(
      productMap
    );


  // مبلغ فروش کالاها
  const values =
    Object.values(
      productMap
    );


  const context =
    $("productSalesChart")
      .getContext(
        "2d"
      );


  // حذف نمودار قبلی قبل از رسم نمودار جدید
  if (
    productSalesChart
  ) {

    productSalesChart.destroy();

  }


  productSalesChart =
    new Chart(
      context,
      {
        type:
          "doughnut",

        data: {

          labels:
            labels.length
              ? labels
              : [
                  "بدون اطلاعات"
                ],

          datasets: [
            {
              data:
                values.length
                  ? values
                  : [
                      1
                    ],

              // اگر اطلاعات داشته باشیم رنگ‌های سبز استفاده می‌شوند.
              // در حالت بدون اطلاعات خاکستری نمایش داده می‌شود.
              backgroundColor:
                values.length

                  ? [
                      "#059669",
                      "#10B981",
                      "#34D399",
                      "#6EE7B7",
                      "#A7F3D0",
                      "#047857",
                      "#065F46",
                      "#F59E0B"
                    ]

                  : [
                      "#E2E8F0"
                    ],

              borderWidth:
                0
            }
          ]

        },

        options: {

          responsive:
            true,

          maintainAspectRatio:
            false,

          plugins: {

            legend: {
              position:
                "right"
            }

          }

        }
      }
    );
}



// ========================================================
// 33. نمایش / مخفی کردن Loading
// ========================================================

function showLoading(show) {

  // اگر show=true باشد hidden حذف می‌شود.
  loadingOverlay
    .classList
    .toggle(
      "hidden",
      !show
    );


  // و flex فعال می‌شود.
  loadingOverlay
    .classList
    .toggle(
      "flex",
      show
    );
}



// ========================================================
// 34. نمایش پیام موفقیت یا خطا
// ========================================================

function showMessage(
  message,
  type
) {

  formMessage.textContent =
    message;


  // کلاس پایه
  formMessage.className =
    `mt-4 text-sm ${
      type === "success"
        ? "text-emerald-600"
        : "text-red-600"
    }`;


  formMessage
    .classList
    .remove(
      "hidden"
    );


  // بعد از 3.5 ثانیه پیام مخفی می‌شود.
  setTimeout(
    () =>
      formMessage
        .classList
        .add(
          "hidden"
        ),
    3500
  );
}



// ========================================================
// 35. فرمت عدد با جداکننده هزارگان فارسی
// ========================================================
//
// مثال:
// 2500000000
// => ۲٬۵۰۰٬۰۰۰٬۰۰۰
//
function formatNumber(value) {

  return Number(
    value ||
    0
  )
  .toLocaleString(
    "fa-IR"
  );
}



// ========================================================
// 36. فرمت عدد اعشاری
// ========================================================
//
// مثال:
// 12.567
// => ۱۲٫۶
//
function formatDecimal(value) {

  return Number(
    value ||
    0
  )
  .toLocaleString(
    "fa-IR",
    {
      maximumFractionDigits:
        1
    }
  );
}



// ========================================================
// 37. تبدیل سال به ارقام فارسی
// ========================================================
//
// مثال:
// 1405 => ۱۴۰۵
//
function toPersianDigits(value) {

  return Number(
    value
  )
  .toLocaleString(
    "fa-IR",
    {
      useGrouping:
        false
    }
  );
}



// ========================================================
// 38. یکسان‌سازی متن برای مقایسه
// ========================================================
//
// trim()        = حذف فاصله اول و آخر
// toLowerCase() = تبدیل حروف انگلیسی به lowercase
//
// برای مقایسه NAME / TEAM / MONTH استفاده می‌شود.
//
function normalizeText(value) {

  return String(
    value ||
    ""
  )
  .trim()
  .toLowerCase();
}



// ========================================================
// 39. ساخت ID داخلی برای هر Activity
// ========================================================
//
// این ID فقط برای ویرایش و حذف Activity داخل Array است.
//
// با ID رکورد MockAPI فرق دارد.
//
// مثال:
// 1758000000000-a4fd2e
//
function createActivityId() {

  return `${Date.now()}-${
    Math.random()
      .toString(16)
      .slice(2)
  }`;
}
